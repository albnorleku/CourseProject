package com.roiacademy;

import com.roiacademy.newPackage.Dog;

public class Main {
    protected String test;

    /**
     * This is main method
     *
     * @param args
     */
    public static void main(String[] args) {
	// write your code here

        int i = 10;
        int n = ++i % 5;
        System.out.println(n);
        System.out.println(i--);
        System.out.println(i);


        Dog dog = new Dog("good boy");
        Dog dog2 = new Dog();
        //dog.setName("good boy");
        dog2.setName("bad boy");
        System.out.println(dog.getName());
//
//
//
//        Object a = "test";
//        int b = 24;
//        int ab = 21;
//
//        while (ab < b) {
//            System.out.println(ab);
//            if( ab == 22) {
//                continue;
//                //break;
//            }
//            ab++;
//            //logic
//            System.out.println("hi not 22");
//        }

        /*do {

        } while ();*/



       /* String [] array = new String[3];
        array[0] = "test";
        array[1] = "test2";
        array[2] = "test3";
        for(int i = 0; i < array.length; i++) {
            System.out.println(array[i]);
        }

        for (String word : array) {
            System.out.println(word);
        }*/

/*
       int [] intArray = new int[23];
       System.out.println(intArray[22]);
       for(int i = 0; i < intArray.length; i++) {
            intArray[i] = i * i;
        }

       for(int i : intArray) {

           System.out.println(i);
       }*/
    }

}
